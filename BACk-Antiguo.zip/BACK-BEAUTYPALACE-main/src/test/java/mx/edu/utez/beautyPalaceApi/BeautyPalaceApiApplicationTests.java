package mx.edu.utez.beautyPalaceApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeautyPalaceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

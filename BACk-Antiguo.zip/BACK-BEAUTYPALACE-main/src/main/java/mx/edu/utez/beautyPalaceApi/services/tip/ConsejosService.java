package mx.edu.utez.beautyPalaceApi.services.tip;

import mx.edu.utez.beautyPalaceApi.models.question.Preguntas;
import mx.edu.utez.beautyPalaceApi.models.tip.Consejos;
import mx.edu.utez.beautyPalaceApi.models.tip.ConsejosRepository;
import mx.edu.utez.beautyPalaceApi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.List;

@Service
@Transactional
public class ConsejosService {
    @Autowired
    private ConsejosRepository repository;


    @Transactional(readOnly = true)
    public Response<List<Consejos>> getAllConsejos(){
        return new Response<>(
                this.repository.findAll(),
                false,
                200,
                "Ok"
        );
    }

    @Transactional(rollbackFor = SQLException.class)
    public Response<Consejos> insertOne(Consejos consejos){
        if (!this.repository.existsById(consejos.getId())){
            return new Response<>(
                    this.repository.saveAndFlush(consejos),
                    false,
                    200,
                    "ok"
            );
        }
        return new Response<>(
                null,
                true,
                400,
                "No se pudo agregar el consejo"
        );
    }

    @Transactional(rollbackFor = SQLException.class)
    public Response<Consejos> updateConsejos(Consejos consejos) {
        if (this.repository.existsById(consejos.getId())) {
            if (this.repository.updateConsejo(
                    consejos.getTitulo(),
                    consejos.getConsejo(),
                    consejos.getId()
            ) == 1) {
                return new Response<>(
                        consejos,
                        false,
                        200,
                        "El consejo se actualizo correctamente"
                );
            } else {
                return new Response<>(
                        null,
                        true,
                        400,
                        "Algo salio mal al actualizar el consejo"
                );
            }
        } else {
            return new Response<>(
                    null,
                    true,
                    400,
                    "El consejo no se encontro"
            );
        }
    }

    @Transactional(rollbackFor = SQLException.class)
    public Response<Consejos> deleteConsejoById(Long id) {
        if (this.repository.existsById(id)) {
            this.repository.deleteConsejosById(id);
            return new Response<>(
                    null,
                    false,
                    200,
                    "ok"
            );
        }
        return new Response<>(
                null,
                true,
                400,
                "No se encontro el Consejo"
        );
    }
}

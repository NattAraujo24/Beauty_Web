package mx.edu.utez.beautyPalaceApi.models.agenda;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Repository
public interface AgendaRepository extends JpaRepository<Agenda, Long> {

    @Modifying
    @Query(
            value = "UPDATE agenda SET name = :name, name_client = :nameClient, type_of_service= :typeOfService,day= :day, start_time= :startTime, time_end= :timeEnd, branch = :branch WHERE id = :id ",
            nativeQuery = true
    )
    int agendaUpdate(String name,String nameClient,String typeOfService,String day,String startTime,String timeEnd, String branch, Long id);



    @Query(
            value = "SELECT agenda.* from agenda JOIN user ON user.name = agenda.name_client WHERE user.id = :id",
            nativeQuery = true
    )
    List<Object> findAgendaByUserId(Long id);

    @Query(
            value = "SELECT * from agenda WHERE agenda.id = :id",
            nativeQuery = true
    )
    List<Agenda> findAgendaById(Long id);


    @Modifying
    @Query("DELETE FROM Agenda a WHERE a.day < :day")
    void deleteCitasAnteriores(@Param("day") LocalDate day);

}

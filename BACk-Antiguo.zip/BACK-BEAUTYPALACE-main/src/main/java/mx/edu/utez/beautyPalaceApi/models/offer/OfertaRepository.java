package mx.edu.utez.beautyPalaceApi.models.offer;

import mx.edu.utez.beautyPalaceApi.models.product.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface OfertaRepository extends JpaRepository<Oferta, Long> {

    boolean existsByNombre(String nombre);

    @Modifying
    @Query(
            value = "UPDATE oferta SET nombre = :nombre, descuento = :descuento, nombre_producto  = :product, descripcion = :descripcion,  fecha_inicio= :fechaInicio WHERE id= :id",
            nativeQuery = true
    )
    int updateOferta(String nombre, Long descuento, Product product, String descripcion, Date fechaInicio, Long id);

    @Modifying
    @Query(
            value = "DELETE FROM oferta WHERE id = :id",
            nativeQuery = true
    )
    void deleteById(Long id);

}
